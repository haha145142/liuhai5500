import { createServerFn } from "@tanstack/react-start";
import { asArr, fetchText, n, parseMaybeJsonp } from "./fetch-util";
import { GLOBAL_DEFS, INDEX_DEFS, SECTOR_RULES } from "./sectors";
import { calcIndicators } from "../calc/indicators";
import type {
  BoardQuote,
  DataSource,
  FundQuote,
  GlobalQuote,
  IndexQuote,
  MarketOrder,
  NewsFeed,
  NewsItem,
  RankRow,
  SectorQuote,
  Snapshot,
} from "../types";
import { safeText } from "../format";

const EM_UT = "fa5fd1943c7b386f172d6893dbfba10b";
const EM_REFERER = "https://quote.eastmoney.com/";

type CacheEntry<T> = { ts: number; data: T };
const mem = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttl: number, data: T | null): T | null {
  if (data) mem.set(key, { ts: Date.now(), data });
  const hit = mem.get(key) as CacheEntry<T> | undefined;
  if (hit && Date.now() - hit.ts < ttl) return hit.data;
  return data;
}

function src(name: string, ok: boolean, note: string): DataSource {
  return { name, status: ok ? "ok" : "err", note };
}

async function emJson(url: string, timeout = 10000): Promise<unknown> {
  const text = await fetchText(url, timeout, { Referer: EM_REFERER });
  return parseMaybeJsonp(text);
}

async function fetchIndices(): Promise<{ list: IndexQuote[]; source: DataSource }> {
  const secids = INDEX_DEFS.map((x) => x.secid).join(",");
  try {
    const j = (await emJson(
      `https://push2.eastmoney.com/api/qt/ulist.np/get?fltt=2&invt=2&fields=f12,f14,f2,f3,f4&secids=${secids}&ut=${EM_UT}&_=${Date.now()}`,
    )) as { data?: { diff?: unknown } };
    const arr = asArr(j?.data?.diff);
    if (arr.length) {
      const list = INDEX_DEFS.map((d) => {
        const x = arr.find((v) => String(v.f12) === d.code) || {};
        return {
          name: d.name,
          code: d.code,
          secid: d.secid,
          price: n(x.f2),
          pct: n(x.f3),
          change: n(x.f4),
        };
      });
      if (list.some((x) => x.pct != null)) {
        return { list, source: src("指数", true, "东方财富实时行情") };
      }
    }
  } catch {
    /* fallback */
  }
  try {
    const codes = ["sh000001", "sz399001", "sz399006", "sh000688"];
    const text = await fetchText(`https://qt.gtimg.cn/q=${codes.join(",")}`, 8000);
    const lines = text.split(";");
    const list: IndexQuote[] = INDEX_DEFS.map((d, i) => {
      const line = lines[i] || "";
      const m = line.match(/="([^"]*)"/);
      const p = m ? m[1].split("~") : [];
      return {
        name: d.name,
        code: d.code,
        secid: d.secid,
        price: n(p[3]),
        pct: n(p[32]),
        change: n(p[31]),
      };
    });
    return { list, source: src("指数", list.some((x) => x.pct != null), "腾讯财经兜底") };
  } catch {
    return {
      list: INDEX_DEFS.map((d) => ({
        name: d.name, code: d.code, secid: d.secid, price: null, pct: null, change: null,
      })),
      source: src("指数", false, "数据源暂不可用"),
    };
  }
}

async function fetchBoards(): Promise<{
  sectors: SectorQuote[];
  boards: BoardQuote[];
  source: DataSource;
}> {
  const fields = "f12,f14,f2,f3,f62,f66,f69,f72,f75,f6";
  async function clist(fs: string, type: "industry" | "concept") {
    const j = (await emJson(
      `https://push2.eastmoney.com/api/qt/clist/get?pn=1&pz=80&po=1&np=1&fltt=2&invt=2&fid=f3&fs=${encodeURIComponent(fs)}&fields=${fields}&ut=${EM_UT}&_=${Date.now()}`,
      12000,
    )) as { data?: { diff?: unknown } };
    return asArr(j?.data?.diff).map((x) => ({
      code: String(x.f12 || ""),
      name: String(x.f14 || ""),
      type,
      change: n(x.f3),
      flow: n(x.f62),
      super: n(x.f66),
      large: n(x.f69),
      mid: n(x.f72),
      small: n(x.f75),
      turnover: n(x.f6),
    }));
  }

  try {
    const [ind, con] = await Promise.all([
      clist("m:90+t:2", "industry"),
      clist("m:90+t:3", "concept"),
    ]);
    const all = [...ind, ...con];
    const boards: BoardQuote[] = all
      .filter((x) => x.name && x.change != null)
      .map((x) => ({ code: x.code, name: x.name, type: x.type, change: x.change, flow: x.flow }));

    const sectors: SectorQuote[] = SECTOR_RULES.map((r) => {
      const hit =
        all.find((x) => x.code === r.bkCode) ||
        all.find((x) => x.name === r.name) ||
        all.find((x) => r.searchKeys.some((k) => x.name.includes(k)));
      return {
        id: r.id,
        name: r.name,
        bkCode: r.bkCode,
        change: hit?.change ?? null,
        flow: hit?.flow ?? null,
        super: hit?.super ?? null,
        large: hit?.large ?? null,
        mid: hit?.mid ?? null,
        small: hit?.small ?? null,
        turnover: hit?.turnover ?? null,
        available: hit?.change != null,
        streak: 0,
        etfCode: r.etf?.code,
        etfName: r.etf?.name,
      };
    });
    return {
      sectors,
      boards: boards.sort((a, b) => (b.change ?? -999) - (a.change ?? -999)),
      source: src("板块", sectors.some((s) => s.available), "东方财富板块资金"),
    };
  } catch {
    return {
      sectors: SECTOR_RULES.map((r) => ({
        id: r.id, name: r.name, bkCode: r.bkCode,
        change: null, flow: null, super: null, large: null, mid: null, small: null,
        turnover: null, available: false, streak: 0, etfCode: r.etf?.code, etfName: r.etf?.name,
      })),
      boards: [],
      source: src("板块", false, "数据源暂不可用"),
    };
  }
}

async function fetchFlow(): Promise<{ flow: MarketOrder | null; source: DataSource }> {
  try {
    const j = (await emJson(
      `https://push2.eastmoney.com/api/qt/clist/get?pn=1&pz=400&po=1&np=1&fltt=2&invt=2&fid=f62&fs=${encodeURIComponent("m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23")}&fields=f62,f66,f69,f72,f75&ut=${EM_UT}&_=${Date.now()}`,
      12000,
    )) as { data?: { diff?: unknown } };
    const arr = asArr(j?.data?.diff);
    if (!arr.length) throw new Error("empty");
    const sum = (k: string) => arr.reduce((s, x) => s + (n(x[k]) || 0), 0);
    const flow: MarketOrder = {
      main: sum("f62"),
      super: sum("f66"),
      large: sum("f69"),
      mid: sum("f72"),
      small: sum("f75"),
      count: arr.length,
    };
    return { flow, source: src("资金", true, `东方财富全A抽样 ${arr.length} 只`) };
  } catch {
    return { flow: null, source: src("资金", false, "数据源暂不可用") };
  }
}

async function fetchGlobal(): Promise<{ list: GlobalQuote[]; source: DataSource }> {
  try {
    const q = GLOBAL_DEFS.map((x) => x.tencent).join(",");
    const text = await fetchText(`https://qt.gtimg.cn/q=${q}`, 8000);
    const chunks = text.split(";");
    const list: GlobalQuote[] = GLOBAL_DEFS.map((d, i) => {
      const line = chunks[i] || "";
      const m = line.match(/="([^"]*)"/);
      const p = m ? m[1].split("~") : [];
      return { name: d.name, price: n(p[3]), pct: n(p[32]) ?? n(p[31]) };
    });
    return { list, source: src("外围", list.some((x) => x.pct != null), "腾讯财经") };
  } catch {
    return { list: [], source: src("外围", false, "数据源暂不可用") };
  }
}

export const getSnapshot = createServerFn({ method: "GET" }).handler(async (): Promise<Snapshot> => {
  const hit = cached<Snapshot>("snap", 20_000, null);
  if (hit) return hit;
  const [idx, boards, flow, global] = await Promise.all([
    fetchIndices(),
    fetchBoards(),
    fetchFlow(),
    fetchGlobal(),
  ]);
  const snap: Snapshot = {
    indices: idx.list,
    sectors: boards.sectors,
    boards: boards.boards.slice(0, 40),
    flow: flow.flow,
    global: global.list,
    sources: [idx.source, boards.source, flow.source, global.source],
    fetchedAt: Date.now(),
  };
  return cached("snap", 20_000, snap)!;
});

function hashId(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return String(h);
}

function classifyNews(title: string): NewsItem["category"] {
  if (/政策|国务院|央行|财政部|证监会|发改委|降准|降息|LPR/.test(title)) return "policy";
  if (/美股|美联储|美元|黄金|原油|纳指|标普|港股|恒生|外围/.test(title)) return "global";
  if (/半导体|芯片|白酒|新能源|军工|医药|人工智能|机器人/.test(title)) return "sector";
  if (/A股|上证|深成|创业板|大盘|北向|成交/.test(title)) return "market";
  return "other";
}

function newsSentiment(title: string): NewsItem["sentiment"] {
  if (/涨|升|新高|流入|利好|突破|反弹|超预期/.test(title)) return "bull";
  if (/跌|崩|跳水|利空|制裁|冲突|暴雷|处罚|下滑/.test(title)) return "bear";
  return "neutral";
}

function relatedSectors(title: string): string[] {
  return SECTOR_RULES.filter((r) => r.keys.some((k) => title.includes(k))).map((r) => r.name);
}

function parsePublished(raw: unknown): number | null {
  if (raw == null || raw === "") return null;
  if (typeof raw === "number") {
    if (raw > 1e12) return raw;
    if (raw > 1e9) return raw * 1000;
    return null;
  }
  const s = String(raw).trim();
  if (!s || /刚刚|刚才|刚刚发布/.test(s)) return null;
  if (/^\d{10,13}$/.test(s)) {
    const n0 = Number(s);
    return s.length === 10 ? n0 * 1000 : n0;
  }
  const iso = Date.parse(s.replace(/-/g, "/"));
  if (Number.isFinite(iso) && iso > 0) return iso;
  return null;
}

function toNews(
  title: string,
  summary: string,
  source: string,
  publishedAt: number | null,
  url: string,
  fetchedAt: number,
): NewsItem | null {
  const t = safeText(title);
  if (!t) return null;
  return {
    id: hashId(source + t),
    title: t,
    summary: safeText(summary).slice(0, 180),
    source,
    url,
    publishedAt,
    fetchedAt,
    category: classifyNews(t),
    sentiment: newsSentiment(t),
    relatedSectors: relatedSectors(t),
  };
}

async function fetchTHS(fetchedAt: number): Promise<NewsItem[]> {
  try {
    const j = (await emJson(
      "https://news.10jqka.com.cn/tapp/news/push/stock/?page=1&pagesize=40&track=website",
      10000,
    )) as { data?: { list?: Record<string, unknown>[] } };
    const list = j?.data?.list || [];
    return list
      .map((x) =>
        toNews(
          String(x.title || ""),
          String(x.digest || x.summary || ""),
          "同花顺",
          parsePublished(x.ctime),
          String(x.url || ""),
          fetchedAt,
        ),
      )
      .filter((x): x is NewsItem => !!x);
  } catch {
    return [];
  }
}

async function fetchEmFlash(fetchedAt: number): Promise<NewsItem[]> {
  try {
    const j = (await emJson(
      `https://np-listapi.eastmoney.com/comm/web/getFastNewsList?client=web&biz=web_724&fastColumn=102&sortEnd=&pageSize=30&type=0&_=${Date.now()}`,
      10000,
    )) as { data?: { fastNewsList?: Record<string, unknown>[] } };
    const list = j?.data?.fastNewsList || [];
    return list
      .map((x) =>
        toNews(
          String(x.title || x.showTitle || ""),
          String(x.digest || x.summary || ""),
          "东方财富快讯",
          parsePublished(x.showTime || x.date || x.time),
          String(x.url || x.code_name || ""),
          fetchedAt,
        ),
      )
      .filter((x): x is NewsItem => !!x);
  } catch {
    return [];
  }
}

async function fetchWscn(fetchedAt: number): Promise<NewsItem[]> {
  try {
    const j = (await emJson(
      "https://api-one-wscn.awtmt.com/apiv1/content/lives?channel=global-channel&client=pc&limit=20",
      10000,
    )) as { data?: { items?: Record<string, unknown>[] } };
    const list = j?.data?.items || [];
    return list
      .map((x) =>
        toNews(
          String(x.title || x.content_text || "").slice(0, 80),
          String(x.content_text || x.content || ""),
          "华尔街见闻",
          parsePublished(x.display_time || x.created_at),
          String(x.uri || x.url || ""),
          fetchedAt,
        ),
      )
      .filter((x): x is NewsItem => !!x);
  } catch {
    return [];
  }
}

async function fetchGuba(fetchedAt: number): Promise<NewsItem[]> {
  try {
    const j = (await emJson(
      "https://guba.eastmoney.com/interface/GetData.aspx?path=topics/hotlist&param=ps=15&p=1",
      8000,
    )) as { re?: Record<string, unknown>[] } | Record<string, unknown>[];
    const list = Array.isArray(j) ? j : (j as { re?: Record<string, unknown>[] })?.re || [];
    return list
      .map((x) =>
        toNews(
          String(x.title || x.post_title || ""),
          "股吧热帖 · 社区情绪，非官方新闻",
          "东方财富股吧",
          parsePublished(x.post_publish_time || x.time),
          String(x.post_url || ""),
          fetchedAt,
        ),
      )
      .filter((x): x is NewsItem => !!x);
  } catch {
    return [];
  }
}

export const getNews = createServerFn({ method: "GET" }).handler(async (): Promise<NewsFeed> => {
  const hit = cached<NewsFeed>("news", 60_000, null);
  if (hit) return hit;
  const fetchedAt = Date.now();
  const [ths, em, wscn, guba] = await Promise.all([
    fetchTHS(fetchedAt),
    fetchEmFlash(fetchedAt),
    fetchWscn(fetchedAt),
    fetchGuba(fetchedAt),
  ]);
  const seen = new Set<string>();
  const items: NewsItem[] = [];
  for (const n0 of [...ths, ...em, ...wscn]) {
    if (seen.has(n0.title)) continue;
    seen.add(n0.title);
    items.push(n0);
  }
  items.sort((a, b) => (b.publishedAt || 0) - (a.publishedAt || 0));
  const latest = items.map((x) => x.publishedAt).filter((x): x is number => x != null && x > 0);
  const feed: NewsFeed = {
    items: items.slice(0, 50),
    deep: items.filter((x) => x.summary.length > 40).slice(0, 12),
    sentiment: guba.slice(0, 12),
    sources: [
      src("同花顺", ths.length > 0, ths.length ? `${ths.length} 条` : "暂不可用"),
      src("东财快讯", em.length > 0, em.length ? `${em.length} 条` : "暂不可用"),
      src("华尔街见闻", wscn.length > 0, wscn.length ? `${wscn.length} 条` : "暂不可用"),
      src("社区情绪", guba.length > 0, guba.length ? `${guba.length} 条` : "暂不可用"),
    ],
    fetchedAt,
    latestPublishedAt: latest.length ? Math.max(...latest) : null,
  };
  return cached("news", 60_000, feed)!;
});

export const getFund = createServerFn({ method: "POST" })
  .validator((input: { code: string }) => input)
  .handler(async ({ data }): Promise<FundQuote> => {
    const code = data.code.replace(/\D/g, "").slice(0, 6);
    const empty: FundQuote = {
      code, name: code, type: "基金", nav: null, navDate: null,
      estimate: null, estimatePct: null, estimateTime: null,
      dayPct: null, weekPct: null, monthPct: null, history: [], metrics: null, source: "数据源暂不可用",
    };
    if (!/^\d{6}$/.test(code)) return empty;

    let name = code;
    let nav: number | null = null;
    let navDate: string | null = null;
    let dayPct: number | null = null;
    const history: number[] = [];
    let source = "数据源暂不可用";

    try {
      const j = (await emJson(
        `https://api.fund.eastmoney.com/f10/lsjz?fundCode=${code}&pageIndex=1&pageSize=60`,
        10000,
      )) as { Data?: { LSJZList?: Record<string, unknown>[] } };
      const rows = (j?.Data?.LSJZList || []).slice().reverse();
      for (const r of rows) {
        const v = n(r.DWJZ);
        if (v != null) history.push(v);
      }
      const last = j?.Data?.LSJZList?.[0];
      if (last) {
        nav = n(last.DWJZ);
        navDate = String(last.FSRQ || "") || null;
        dayPct = n(last.JZZZL);
        source = "东方财富历史净值";
      }
    } catch {
      /* continue */
    }

    try {
      const text = await fetchText(`https://fundgz.1234567.com.cn/js/${code}.js?rt=${Date.now()}`, 8000, {
        Referer: "https://fund.eastmoney.com/",
      });
      const gz = parseMaybeJsonp(text) as Record<string, unknown> | null;
      if (gz) {
        name = String(gz.name || name);
        if (nav == null) nav = n(gz.dwjz);
        if (!navDate) navDate = String(gz.jzrq || "") || null;
        empty.estimate = n(gz.gsz);
        empty.estimatePct = n(gz.gszzl);
        empty.estimateTime = String(gz.gztime || "") || null;
        if (source === "数据源暂不可用") source = "天天基金估值";
        else source += " + 天天基金估值";
      }
    } catch {
      /* optional */
    }

    if (name === code) {
      try {
        const j = (await emJson(
          `https://fundsuggest.eastmoney.com/FundSearch/api/FundSearchAPI.ashx?m=1&key=${code}`,
          6000,
        )) as { Datas?: { CODE?: string; NAME?: string; CATEGORYDESC?: string }[] };
        const hit = (j?.Datas || []).find((x) => x.CODE === code) || j?.Datas?.[0];
        if (hit?.NAME) name = hit.NAME;
        if (hit?.CATEGORYDESC) empty.type = hit.CATEGORYDESC;
      } catch {
        /* optional */
      }
    }

    const metrics = calcIndicators(history);
    const weekPct =
      history.length >= 6 && history[history.length - 1]
        ? ((history[history.length - 1] - history[history.length - 6]) / history[history.length - 6]) * 100
        : null;
    const monthPct =
      history.length >= 21 && history[history.length - 1]
        ? ((history[history.length - 1] - history[history.length - 21]) / history[history.length - 21]) * 100
        : null;

    return {
      ...empty,
      code,
      name,
      nav,
      navDate,
      dayPct,
      weekPct,
      monthPct,
      history,
      metrics,
      source,
      estimate: empty.estimate,
      estimatePct: empty.estimatePct,
      estimateTime: empty.estimateTime,
    };
  });

export const searchFund = createServerFn({ method: "POST" })
  .validator((input: { q: string }) => input)
  .handler(async ({ data }): Promise<{ code: string; name: string; type: string }[]> => {
    const q = data.q.trim();
    if (!q) return [];
    try {
      const j = (await emJson(
        `https://fundsuggest.eastmoney.com/FundSearch/api/FundSearchAPI.ashx?m=1&key=${encodeURIComponent(q)}`,
        8000,
      )) as { Datas?: { CODE?: string; NAME?: string; CATEGORYDESC?: string }[] };
      return (j?.Datas || [])
        .filter((x) => x.CODE && x.NAME)
        .slice(0, 8)
        .map((x) => ({ code: String(x.CODE), name: String(x.NAME), type: String(x.CATEGORYDESC || "基金") }));
    } catch {
      return [];
    }
  });

export const getFundRank = createServerFn({ method: "POST" })
  .validator((input: { sort?: string }) => input)
  .handler(async ({ data }): Promise<{ rows: RankRow[]; source: string; fetchedAt: number }> => {
    const sort = data.sort || "r";
    const sc = sort === "z" ? "zzf" : sort === "1n" ? "1nzf" : sort === "6y" ? "6yzf" : "rzf";
    try {
      const text = await fetchText(
        `https://fund.eastmoney.com/data/rankhandler.aspx?op=ph&dt=kf&ft=all&rs=&gs=0&sc=${sc}&st=desc&pi=1&pn=40&dx=1&_=${Date.now()}`,
        12000,
        { Referer: "https://fund.eastmoney.com/" },
      );
      const j = parseMaybeJsonp(text) as { datas?: string[] } | null;
      const rows: RankRow[] = (j?.datas || []).map((line) => {
        const a = String(line).split(",");
        return {
          code: a[0] || "",
          name: a[1] || "",
          nav: n(a[4]),
          day: n(a[6]),
          week: n(a[7]),
          month: n(a[8]),
          ytd: n(a[14]),
        };
      }).filter((x) => x.code && x.name);
      return { rows, source: rows.length ? "天天基金/东方财富排行" : "数据源暂不可用", fetchedAt: Date.now() };
    } catch {
      return { rows: [], source: "数据源暂不可用", fetchedAt: Date.now() };
    }
  });

export const analyzeMarket = createServerFn({ method: "POST" })
  .validator((input: { prompt: string }) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "AI 暂不可用", text: "" };
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 700,
        messages: [
          {
            role: "system",
            content:
              "你是严谨的基金投研助手。只用用户提供的证据，没有就写「暂无可靠数据」，绝不编造数字。用大白话中文。不构成投资建议。按7步：发生了什么/市场反应/资金确认/新闻催化/政策支持/外围共振/最后判断。",
          },
          { role: "user", content: data.prompt.slice(0, 6000) },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `AI 接口 ${res.status}`, text: "" };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return { ok: true as const, error: "", text: body.choices?.[0]?.message?.content ?? "" };
  });
